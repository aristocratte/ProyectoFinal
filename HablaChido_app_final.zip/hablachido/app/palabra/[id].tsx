import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Speech from 'expo-speech';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFavoritos } from '../../lib/favorites';
import { buscarPorId } from '../../lib/palabras';
import { colors, fonts } from '../../lib/theme';

const volver = () => (router.canGoBack() ? router.back() : router.replace('/'));

export default function Ficha() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { esFavorito, alternar } = useFavoritos();
  const insets = useSafeAreaInsets();
  const p = id ? buscarPorId(String(id)) : undefined;

  if (!p) {
    return (
      <View style={styles.centro}>
        <Text style={styles.sig}>No encontramos esta palabra.</Text>
        <Pressable onPress={volver} style={[styles.botonRojo, { flex: 0, paddingHorizontal: 28 }]}>
          <Text style={styles.botonRojoTexto}>Volver</Text>
        </Pressable>
      </View>
    );
  }

  const favorito = esFavorito(p.id);
  const decir = (texto: string) => {
    Speech.stop();
    Speech.speak(texto, { language: 'es-MX' });
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <View style={[styles.barra, { paddingTop: insets.top + 12 }]}>
        <Pressable style={styles.circulo} onPress={volver} accessibilityLabel="Volver" accessibilityRole="button">
          <Ionicons name="arrow-back" size={20} color={colors.navy} />
        </Pressable>
        <Pressable
          style={[styles.circulo, favorito && { backgroundColor: colors.red }]}
          onPress={() => alternar(p.id)}
          accessibilityLabel={favorito ? 'Quitar de favoritos' : 'Agregar a favoritos'}
          accessibilityRole="button"
        >
          <Ionicons name={favorito ? 'heart' : 'heart-outline'} size={20} color={favorito ? '#FFFFFF' : colors.navy} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 120 }}>
        <View style={styles.tag}>
          <Text style={styles.tagTexto}>{p.categoria}</Text>
        </View>
        <Text style={styles.titulo} numberOfLines={2} adjustsFontSizeToFit minimumFontScale={0.5}>{p.palabra}</Text>
        <Text style={styles.sig}>{p.significado}</Text>
        {p.registro === 'vulgar' && <Text style={styles.aviso}>Palabra vulgar: evítala en contextos formales.</Text>}
        <Text style={styles.traduccionPalabra}>FR · {p.fr}   ·   EN · {p.en}</Text>

        <View style={styles.contexto}>
          <View style={styles.filaContexto}>
            <Text style={styles.etiqueta}>CONTEXTO</Text>
            <Pressable onPress={() => decir(p.ejemplo)} hitSlop={10} accessibilityLabel="Escuchar el ejemplo" accessibilityRole="button">
              <Ionicons name="volume-medium" size={20} color={colors.muted} />
            </Pressable>
          </View>
          <Text style={styles.ejemplo}>«{p.ejemplo}»</Text>
          <Text style={styles.traduccion}>FR · {p.ejemploFr}</Text>
          <Text style={styles.traduccion}>EN · {p.ejemploEn}</Text>
        </View>
      </ScrollView>

      <View style={[styles.accion, { paddingBottom: insets.bottom + 14 }]}>
        <Pressable style={styles.botonRojo} onPress={() => decir(p.palabra)} accessibilityRole="button">
          <Ionicons name="volume-high" size={18} color="#FFFFFF" />
          <Text style={styles.botonRojoTexto}>Escuchar</Text>
        </Pressable>
        <Pressable style={styles.botonNavy} onPress={() => router.navigate('/quiz')} accessibilityRole="button" accessibilityLabel="Practicar con el quiz">
          <Ionicons name="flash" size={20} color="#FFFFFF" />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  centro: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16, backgroundColor: colors.cream },
  barra: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 8 },
  circulo: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' },
  tag: { alignSelf: 'flex-start', backgroundColor: colors.oro, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5, marginTop: 14 },
  tagTexto: { fontFamily: fonts.negrita, fontSize: 12, color: colors.navy },
  titulo: { fontFamily: fonts.titulo, fontSize: 68, lineHeight: 74, color: colors.navy, marginTop: 6 },
  sig: { fontFamily: fonts.texto, fontSize: 18, color: colors.navy, lineHeight: 26 },
  aviso: { fontFamily: fonts.negrita, fontSize: 13, color: colors.red, marginTop: 8 },
  traduccionPalabra: { fontFamily: fonts.medio, fontSize: 12.5, color: colors.muted, marginTop: 8 },
  contexto: { backgroundColor: colors.card, borderRadius: 24, padding: 18, marginTop: 22, gap: 6 },
  filaContexto: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  etiqueta: { fontFamily: fonts.negrita, fontSize: 10.5, letterSpacing: 1.2, color: colors.red },
  ejemplo: { fontFamily: fonts.negrita, fontSize: 17, color: colors.navy, lineHeight: 24, marginTop: 4, marginBottom: 6 },
  traduccion: { fontFamily: fonts.texto, fontSize: 13, color: colors.muted, lineHeight: 19 },
  accion: { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', gap: 12, paddingHorizontal: 20, paddingTop: 12, backgroundColor: colors.cream },
  botonRojo: { flex: 1, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.red, borderRadius: 16, height: 54 },
  botonRojoTexto: { fontFamily: fonts.negrita, fontSize: 16, color: '#FFFFFF' },
  botonNavy: { width: 54, height: 54, borderRadius: 16, backgroundColor: colors.navy, alignItems: 'center', justifyContent: 'center' },
});
