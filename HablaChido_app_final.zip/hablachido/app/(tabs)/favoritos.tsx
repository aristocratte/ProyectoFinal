import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import PalabraFila from '../../components/PalabraFila';
import { useFavoritos } from '../../lib/favorites';
import { palabras } from '../../lib/palabras';
import { colors, fonts } from '../../lib/theme';

export default function Favoritos() {
  const insets = useSafeAreaInsets();
  const { favoritos } = useFavoritos();
  const lista = palabras.filter((p) => favoritos.includes(p.id));

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <FlatList
        data={lista}
        keyExtractor={(p) => p.id}
        renderItem={({ item }) => <PalabraFila p={item} corazon />}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: insets.top + 24, paddingBottom: 24, flexGrow: 1 }}
        ListHeaderComponent={
          <View style={{ marginBottom: 18 }}>
            <Text style={styles.titulo}>Tus favoritos</Text>
            <Text style={styles.sub}>
              {lista.length === 0 ? 'Aún no has guardado palabras' : `${lista.length} ${lista.length === 1 ? 'palabra guardada' : 'palabras guardadas'}`}
            </Text>
          </View>
        }
        ListEmptyComponent={
          <View style={{ gap: 14 }}>
            <Text style={styles.vacio}>Abre la ficha de una palabra y toca el corazón para guardarla aquí.</Text>
            <Pressable style={styles.botonRojo} onPress={() => router.navigate('/')} accessibilityRole="button">
              <Text style={styles.botonRojoTexto}>Explorar palabras</Text>
            </Pressable>
          </View>
        }
        ListFooterComponent={
          lista.length > 0 ? (
            <Pressable style={styles.repasar} onPress={() => router.navigate('/quiz')} accessibilityRole="button">
              <Ionicons name="flash" size={16} color={colors.navy} />
              <Text style={styles.repasarTexto}>Repasar con un quiz</Text>
            </Pressable>
          ) : undefined
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  titulo: { fontFamily: fonts.titulo, fontSize: 30, color: colors.navy },
  sub: { fontFamily: fonts.texto, fontSize: 13, color: colors.muted, marginTop: 2 },
  vacio: { fontFamily: fonts.medio, fontSize: 15, color: colors.muted, lineHeight: 22 },
  botonRojo: { alignSelf: 'flex-start', backgroundColor: colors.red, borderRadius: 16, paddingHorizontal: 22, paddingVertical: 14 },
  botonRojoTexto: { fontFamily: fonts.negrita, fontSize: 15, color: '#FFFFFF' },
  repasar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: colors.oro, borderRadius: 14, height: 48, marginTop: 8 },
  repasarTexto: { fontFamily: fonts.negrita, fontSize: 14, color: colors.navy },
});
