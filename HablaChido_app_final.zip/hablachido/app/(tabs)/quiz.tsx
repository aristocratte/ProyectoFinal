import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { mezclar, palabras, type Palabra } from '../../lib/palabras';
import { colors, fonts } from '../../lib/theme';

const TOTAL = 10;
const KEY_MEJOR = 'hablachido:mejor-puntaje';

type Pregunta = { palabra: Palabra; opciones: string[] };
type Fase = 'inicio' | 'juego' | 'fin';

function crearPreguntas(): Pregunta[] {
  return mezclar(palabras)
    .slice(0, TOTAL)
    .map((p) => {
      const distractores = mezclar(palabras.filter((o) => o.id !== p.id && o.significado !== p.significado))
        .slice(0, 3)
        .map((o) => o.significado);
      return { palabra: p, opciones: mezclar([p.significado, ...distractores]) };
    });
}

export default function Quiz() {
  const insets = useSafeAreaInsets();
  const [fase, setFase] = useState<Fase>('inicio');
  const [preguntas, setPreguntas] = useState<Pregunta[]>([]);
  const [indice, setIndice] = useState(0);
  const [elegida, setElegida] = useState<string | null>(null);
  const [puntaje, setPuntaje] = useState(0);
  const [mejor, setMejor] = useState<number | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(KEY_MEJOR).then((v) => v && setMejor(Number(v))).catch(() => {});
  }, []);

  const empezar = () => {
    setPreguntas(crearPreguntas());
    setIndice(0);
    setElegida(null);
    setPuntaje(0);
    setFase('juego');
  };

  const responder = (opcion: string) => {
    if (elegida !== null) return;
    setElegida(opcion);
    if (opcion === preguntas[indice].palabra.significado) setPuntaje((s) => s + 1);
  };

  const siguiente = () => {
    if (elegida === null) return;
    if (indice + 1 >= preguntas.length) {
      const nuevoMejor = Math.max(mejor ?? 0, puntaje);
      setMejor(nuevoMejor);
      AsyncStorage.setItem(KEY_MEJOR, String(nuevoMejor)).catch(() => {});
      setFase('fin');
    } else {
      setIndice(indice + 1);
      setElegida(null);
    }
  };

  // ---------- Inicio y resultado
  if (fase !== 'juego') {
    const fin = fase === 'fin';
    const mensaje = puntaje >= 9 ? '¡Ya eres todo un chilango!' : puntaje >= 6 ? '¡Muy bien, vas padre!' : 'Sigue practicando, échale ganas.';
    return (
      <View style={[styles.fondo, { paddingTop: insets.top + 24 }]}>
        <View style={styles.pantalla}>
          <Text style={styles.etiqueta}>{fin ? 'RESULTADO' : 'QUIZ'}</Text>
          {fin ? (
            <>
              <Text style={styles.puntajeGrande}>{puntaje}/{TOTAL}</Text>
              <Text style={styles.texto}>{mensaje}</Text>
            </>
          ) : (
            <>
              <Text style={styles.titulo}>¿Qué tan chilango eres?</Text>
              <Text style={styles.texto}>{TOTAL} preguntas al azar. Elige el significado correcto de cada expresión.</Text>
            </>
          )}
          {mejor !== null && (
            <View style={styles.racha}>
              <Ionicons name="trophy" size={14} color={colors.navy} />
              <Text style={styles.rachaTexto}>Mejor puntaje: {mejor} / {TOTAL}</Text>
            </View>
          )}
        </View>
        <View style={[styles.accion, { paddingBottom: 20 }]}>
          <Pressable style={styles.botonRojo} onPress={empezar} accessibilityRole="button">
            <Text style={styles.botonRojoTexto}>{fin ? 'Volver a jugar' : 'Empezar'}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  // ---------- Juego
  const pregunta = preguntas[indice];
  if (!pregunta) return null;
  const respondida = elegida !== null;

  return (
    <View style={[styles.fondo, { paddingTop: insets.top + 16 }]}>
      <View style={styles.cabecera}>
        <Pressable onPress={() => setFase('inicio')} hitSlop={12} accessibilityLabel="Salir del quiz" accessibilityRole="button">
          <Ionicons name="close" size={20} color={colors.navy} />
        </Pressable>
        <View style={styles.pista}>
          <View style={[styles.relleno, { width: `${((indice + (respondida ? 1 : 0)) / TOTAL) * 100}%` }]} />
        </View>
        <Text style={styles.progreso}>Pregunta {indice + 1} de {TOTAL}</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 28, paddingBottom: 130, gap: 10 }}>
        <Text style={styles.pregEtiqueta}>¿Qué significa…</Text>
        <Text style={styles.pregPalabra} numberOfLines={2} adjustsFontSizeToFit minimumFontScale={0.5}>{pregunta.palabra.palabra}?</Text>
        <View style={{ height: 12 }} />

        {pregunta.opciones.map((op) => {
          const esCorrecta = op === pregunta.palabra.significado;
          const esElegida = op === elegida;
          const marcaOk = respondida && esCorrecta;
          const marcaMal = respondida && esElegida && !esCorrecta;
          return (
            <Pressable
              key={op}
              onPress={() => responder(op)}
              disabled={respondida}
              style={[styles.opcion, marcaOk && styles.opcionOk, marcaMal && styles.opcionMal]}
              accessibilityRole="button"
            >
              <Text style={styles.opcionTexto}>{op}</Text>
              {marcaOk && <Ionicons name="checkmark-circle" size={22} color={colors.navy} />}
              {marcaMal && <Ionicons name="close-circle" size={22} color={colors.red} />}
            </Pressable>
          );
        })}

        {respondida && <Text style={styles.ejemplo}>Ejemplo: «{pregunta.palabra.ejemplo}»</Text>}
      </ScrollView>

      <View style={[styles.accion, { paddingBottom: Math.max(insets.bottom, 12) + 8 }]}>
        <Pressable style={[styles.botonRojo, !respondida && { opacity: 0.45 }]} onPress={siguiente} disabled={!respondida} accessibilityRole="button">
          <Text style={styles.botonRojoTexto}>{indice + 1 >= TOTAL ? 'Ver resultado' : 'Siguiente'}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  fondo: { flex: 1, backgroundColor: colors.cream },
  pantalla: { flex: 1, paddingHorizontal: 20, paddingTop: 12, gap: 10 },
  etiqueta: { fontFamily: fonts.negrita, fontSize: 11, letterSpacing: 1.2, color: colors.red },
  titulo: { fontFamily: fonts.titulo, fontSize: 44, lineHeight: 50, color: colors.navy },
  puntajeGrande: { fontFamily: fonts.titulo, fontSize: 96, lineHeight: 104, color: colors.red },
  texto: { fontFamily: fonts.texto, fontSize: 17, color: colors.muted, lineHeight: 25 },
  racha: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', backgroundColor: colors.oro, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7, marginTop: 8 },
  rachaTexto: { fontFamily: fonts.negrita, fontSize: 12, color: colors.navy },
  cabecera: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20 },
  pista: { flex: 1, height: 8, borderRadius: 4, backgroundColor: colors.oroSoft, overflow: 'hidden' },
  relleno: { height: 8, borderRadius: 4, backgroundColor: colors.red },
  progreso: { fontFamily: fonts.negrita, fontSize: 12, color: colors.navy },
  pregEtiqueta: { fontFamily: fonts.negrita, fontSize: 12, color: colors.muted },
  pregPalabra: { fontFamily: fonts.titulo, fontSize: 54, lineHeight: 60, color: colors.navy },
  opcion: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, backgroundColor: colors.card, borderRadius: 14, borderWidth: 1.5, borderColor: 'transparent', paddingHorizontal: 16, paddingVertical: 16 },
  opcionOk: { backgroundColor: colors.azulSoft, borderColor: colors.navy },
  opcionMal: { backgroundColor: colors.rojoSoft, borderColor: colors.red },
  opcionTexto: { flex: 1, fontFamily: fonts.negrita, fontSize: 14.5, color: colors.navy, lineHeight: 20 },
  ejemplo: { fontFamily: fonts.texto, fontSize: 13.5, color: colors.muted, marginTop: 6, lineHeight: 20 },
  accion: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: 20, paddingTop: 12, backgroundColor: colors.cream },
  botonRojo: { backgroundColor: colors.red, borderRadius: 16, height: 54, alignItems: 'center', justifyContent: 'center' },
  botonRojoTexto: { fontFamily: fonts.negrita, fontSize: 16, color: '#FFFFFF' },
});
