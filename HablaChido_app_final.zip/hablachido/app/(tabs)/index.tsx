import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { FlatList, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import PalabraFila from '../../components/PalabraFila';
import { CATEGORIAS, normalizar, palabraDelDia, palabras, type Categoria } from '../../lib/palabras';
import { useRacha } from '../../lib/racha';
import { colors, fonts } from '../../lib/theme';

type Filtro = Categoria | 'Todo';
const FILTROS: Filtro[] = ['Todo', ...CATEGORIAS];

export default function Palabras() {
  const insets = useSafeAreaInsets();
  const [busqueda, setBusqueda] = useState('');
  const [buscando, setBuscando] = useState(false);
  const [filtro, setFiltro] = useState<Filtro>('Todo');
  const racha = useRacha();
  const delDia = useMemo(() => palabraDelDia(), []);

  const resultados = useMemo(() => {
    const q = normalizar(busqueda.trim());
    return palabras
      .filter((p) => filtro === 'Todo' || p.categoria === filtro)
      .filter((p) => q === '' || normalizar(p.palabra).includes(q) || normalizar(p.significado).includes(q))
      .sort((a, b) => normalizar(a.palabra).localeCompare(normalizar(b.palabra)));
  }, [busqueda, filtro]);

  const mostrarDelDia = busqueda.trim() === '' && filtro === 'Todo';

  return (
    <View style={{ flex: 1, backgroundColor: colors.cream }}>
      <View style={[styles.cabecera, { paddingTop: insets.top + 14 }]}>
        <Text style={styles.marca}>
          Habla<Text style={{ color: colors.red }}>Chido</Text>
        </Text>
        <Pressable
          style={styles.circulo}
          onPress={() => {
            if (buscando) setBusqueda('');
            setBuscando(!buscando);
          }}
          accessibilityLabel={buscando ? 'Cerrar búsqueda' : 'Buscar'}
          accessibilityRole="button"
        >
          <Ionicons name={buscando ? 'close' : 'search'} size={18} color={colors.navy} />
        </Pressable>
      </View>
      {buscando && (
        <View style={{ paddingHorizontal: 20, paddingBottom: 6 }}>
          <TextInput
            style={styles.input}
            placeholder="Buscar palabra..."
            placeholderTextColor={colors.muted}
            value={busqueda}
            onChangeText={setBusqueda}
            autoFocus
            autoCorrect={false}
            autoCapitalize="none"
          />
        </View>
      )}

      <FlatList
        data={resultados}
        keyExtractor={(p) => p.id}
        renderItem={({ item }) => <PalabraFila p={item} />}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 24 }}
        ListHeaderComponent={
          <View>
            {mostrarDelDia && (
              <Pressable
                onPress={() => router.push(`/palabra/${delDia.id}`)}
                style={styles.hero}
                accessibilityRole="button"
                accessibilityLabel={`Palabra del día: ${delDia.palabra}`}
              >
                <Text style={styles.heroEtiqueta}>PALABRA DEL DÍA</Text>
                <Text style={styles.heroPalabra} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>
                  {delDia.palabra}.
                </Text>
                <Text style={styles.heroSig}>{delDia.significado}</Text>
                <View style={styles.racha}>
                  <Ionicons name="flame" size={14} color={colors.navy} />
                  <Text style={styles.rachaTexto}>Racha de {racha} {racha === 1 ? 'día' : 'días'}</Text>
                </View>
              </Pressable>
            )}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filtros}>
              {FILTROS.map((f) => {
                const activo = f === filtro;
                return (
                  <Pressable
                    key={f}
                    onPress={() => setFiltro(f)}
                    style={[styles.chip, activo && styles.chipActivo]}
                    accessibilityRole="button"
                    accessibilityState={{ selected: activo }}
                  >
                    <Text style={[styles.chipTexto, activo && { color: '#FFFFFF' }]}>{f}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          </View>
        }
        ListEmptyComponent={<Text style={styles.vacio}>No encontramos esa palabra todavía.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  cabecera: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 14 },
  marca: { fontFamily: fonts.titulo, fontSize: 22, color: colors.navy },
  circulo: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.card, alignItems: 'center', justifyContent: 'center' },
  input: { backgroundColor: colors.card, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 12, fontFamily: fonts.medio, fontSize: 15, color: colors.navy },
  hero: { backgroundColor: colors.red, borderRadius: 24, padding: 20, gap: 4 },
  heroEtiqueta: { fontFamily: fonts.negrita, fontSize: 10.5, letterSpacing: 1.2, color: '#FFFFFF', opacity: 0.85 },
  heroPalabra: { fontFamily: fonts.titulo, fontSize: 54, lineHeight: 60, color: '#FFFFFF' },
  heroSig: { fontFamily: fonts.medio, fontSize: 15, color: '#FFFFFF' },
  racha: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', backgroundColor: colors.oro, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7, marginTop: 10 },
  rachaTexto: { fontFamily: fonts.negrita, fontSize: 12, color: colors.navy },
  filtros: { gap: 8, paddingVertical: 16 },
  chip: { height: 34, paddingHorizontal: 16, borderRadius: 999, backgroundColor: colors.oroSoft, alignItems: 'center', justifyContent: 'center' },
  chipActivo: { backgroundColor: colors.navy },
  chipTexto: { fontFamily: fonts.negrita, fontSize: 12.5, color: colors.navy },
  vacio: { textAlign: 'center', fontFamily: fonts.medio, color: colors.muted, fontSize: 15, marginTop: 40 },
});
