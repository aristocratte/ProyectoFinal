import { Ionicons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { colors, fonts } from '../../lib/theme';

type IconName = React.ComponentProps<typeof Ionicons>['name'];
const icono = (name: IconName) =>
  function TabIcon({ color }: { color: unknown }) {
    return <Ionicons name={name} size={22} color={color as string} />;
  };

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.red,
        tabBarInactiveTintColor: colors.inactivo,
        tabBarLabelStyle: { fontFamily: fonts.negrita, fontSize: 11 },
        tabBarStyle: { backgroundColor: colors.card, borderTopWidth: 0, elevation: 8, height: 66, paddingTop: 8, paddingBottom: 8 },
      }}
    >
      <Tabs.Screen name="index" options={{ title: 'Palabras', tabBarIcon: icono('book') }} />
      <Tabs.Screen name="favoritos" options={{ title: 'Favoritos', tabBarIcon: icono('heart') }} />
      <Tabs.Screen name="quiz" options={{ title: 'Quiz', tabBarIcon: icono('flash') }} />
    </Tabs>
  );
}
