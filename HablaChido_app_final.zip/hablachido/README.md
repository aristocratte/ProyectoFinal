# HablaChido

Diccionario de bolsillo del español de la Ciudad de México. Funciona sin internet y sin servicios de pago.

Diseño: crema, rojo, azul marino y mostaza, con tipografías Bricolage Grotesque (títulos) y DM Sans (texto). Categorías: Saludo, Sorpresa, Slang, Gente, Comida, Ciudad y Dinero.

## Qué hace
- **Palabras**: 54 expresiones con palabra del día, racha de días, búsqueda (sin importar acentos) y filtro por categoría.
- **Ficha**: categoría, significado, contexto (ejemplo con audio y traducción FR/EN), audio de la palabra y corazón de favorito.
- **Favoritos**: lista guardada en el teléfono.
- **Quiz**: pantalla de inicio, 10 preguntas aleatorias con corrección inmediata, resultado y mejor puntaje guardado.

## Cómo ejecutarla
1. Instala Node.js (versión LTS) y la app **Expo Go** en tu teléfono.
2. En esta carpeta:
   ```bash
   npm install
   npx expo start
   ```
3. Escanea el código QR con Expo Go (el teléfono y la computadora deben estar en la misma red).

## Si `npm install` da un error de dependencias
Usa `npm install --legacy-peer-deps` y luego `npx expo start`.

## Estructura
```
app/                 pantallas (Expo Router)
  _layout.tsx        navegación principal
  (tabs)/            Palabras, Favoritos, Quiz
  palabra/[id].tsx   ficha de una palabra
components/          PalabraFila
lib/                 datos, favoritos (AsyncStorage), tema
data/palabras.json   las expresiones (editable)
```

## Agregar palabras
Edita `data/palabras.json` y agrega un objeto con `id` (texto único), `palabra`, `significado`, `ejemplo`, `ejemploFr`, `ejemploEn`, `registro` (`amistoso`, `coloquial` o `vulgar`), `categoria` (Saludo, Sorpresa, Slang, Gente, Comida, Ciudad o Dinero), `fr` y `en`.

## Tecnología
React Native + Expo (Expo Router), `expo-speech` para el audio (voz es-MX del teléfono) y `@react-native-async-storage/async-storage` para los favoritos. Todo local y gratuito.
