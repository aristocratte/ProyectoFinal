import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { Palabra } from '../lib/palabras';
import { colors, fonts } from '../lib/theme';

export default function PalabraFila({ p, corazon }: { p: Palabra; corazon?: boolean }) {
  return (
    <Pressable
      style={({ pressed }) => [styles.fila, pressed && { opacity: 0.7 }]}
      onPress={() => router.push(`/palabra/${p.id}`)}
      accessibilityRole="button"
      accessibilityLabel={`Ver ficha de ${p.palabra}`}
    >
      <View style={{ flex: 1 }}>
        <Text style={styles.palabra} numberOfLines={1}>{p.palabra}</Text>
        <Text style={styles.sig} numberOfLines={1}>{p.significado}</Text>
      </View>
      {corazon ? (
        <Ionicons name="heart" size={18} color={colors.red} />
      ) : (
        <Ionicons name="chevron-forward" size={20} color={colors.red} />
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  fila: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: colors.card,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 14,
    marginBottom: 10,
  },
  palabra: { fontFamily: fonts.negrita, fontSize: 16, color: colors.navy },
  sig: { fontFamily: fonts.texto, fontSize: 12.5, color: colors.muted, marginTop: 2 },
});
