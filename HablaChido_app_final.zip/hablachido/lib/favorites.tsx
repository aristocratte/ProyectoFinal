import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';

const KEY = 'hablachido:favoritos';

type FavoritosCtx = {
  favoritos: string[];
  esFavorito: (id: string) => boolean;
  alternar: (id: string) => void;
};

const Ctx = createContext<FavoritosCtx>({
  favoritos: [],
  esFavorito: () => false,
  alternar: () => {},
});

export function FavoritosProvider({ children }: { children: React.ReactNode }) {
  const [favoritos, setFavoritos] = useState<string[]>([]);
  const [cargado, setCargado] = useState(false);

  // Cargar favoritos guardados en el teléfono
  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((v) => {
        if (v) setFavoritos(JSON.parse(v));
      })
      .catch(() => {})
      .finally(() => setCargado(true));
  }, []);

  // Guardar cada vez que cambian (después de la carga inicial)
  useEffect(() => {
    if (cargado) AsyncStorage.setItem(KEY, JSON.stringify(favoritos)).catch(() => {});
  }, [favoritos, cargado]);

  const alternar = useCallback((id: string) => {
    setFavoritos((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }, []);

  const esFavorito = useCallback((id: string) => favoritos.includes(id), [favoritos]);

  return <Ctx.Provider value={{ favoritos, esFavorito, alternar }}>{children}</Ctx.Provider>;
}

export const useFavoritos = () => useContext(Ctx);
