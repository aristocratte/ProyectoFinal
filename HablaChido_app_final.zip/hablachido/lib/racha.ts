import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';

const KEY = 'hablachido:racha';
const clave = (d: Date) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;

// Días seguidos que la persona abre la app (se guarda en el teléfono)
export function useRacha(): number {
  const [dias, setDias] = useState(1);
  useEffect(() => {
    (async () => {
      try {
        const hoy = new Date();
        const ayer = new Date(hoy.getTime() - 86400000);
        const raw = await AsyncStorage.getItem(KEY);
        let nuevo = 1;
        if (raw) {
          const r = JSON.parse(raw) as { fecha: string; dias: number };
          if (r.fecha === clave(hoy)) nuevo = r.dias;
          else if (r.fecha === clave(ayer)) nuevo = r.dias + 1;
        }
        setDias(nuevo);
        await AsyncStorage.setItem(KEY, JSON.stringify({ fecha: clave(hoy), dias: nuevo }));
      } catch {
        // sin almacenamiento: se queda en 1
      }
    })();
  }, []);
  return dias;
}
