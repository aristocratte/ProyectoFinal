export const colors = {
  cream: '#FFF4E0',
  card: '#FFFFFF',
  red: '#C8283A',
  navy: '#1B2A4A',
  oro: '#F2B632',
  oroSoft: '#FBE0A0',
  muted: '#5E6B85',
  azulSoft: '#DDEBFF',
  rojoSoft: '#FBE3E6',
  inactivo: '#56627F',
};

export const fonts = {
  titulo: 'BricolageGrotesque_800ExtraBold',
  tituloMedio: 'BricolageGrotesque_700Bold',
  texto: 'DMSans_400Regular',
  medio: 'DMSans_500Medium',
  negrita: 'DMSans_700Bold',
};
