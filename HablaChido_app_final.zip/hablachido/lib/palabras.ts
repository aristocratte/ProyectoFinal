import data from '../data/palabras.json';

export type Registro = 'amistoso' | 'coloquial' | 'vulgar';
export const CATEGORIAS = ['Saludo', 'Sorpresa', 'Slang', 'Gente', 'Comida', 'Ciudad', 'Dinero'] as const;
export type Categoria = (typeof CATEGORIAS)[number];

export type Palabra = {
  id: string;
  palabra: string;
  significado: string;
  ejemplo: string;
  ejemploFr: string;
  ejemploEn: string;
  registro: Registro;
  categoria: Categoria;
  fr: string;
  en: string;
};

export const palabras = data as Palabra[];

export const buscarPorId = (id: string) => palabras.find((p) => p.id === id);

// Normaliza para buscar sin acentos ni mayúsculas ("orale" encuentra "Órale")
export const normalizar = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

export function mezclar<T>(arr: T[]): T[] {
  const copia = [...arr];
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

// Palabra del día: cambia cada día, igual para todos
export function palabraDelDia(): Palabra {
  const hoy = new Date();
  const inicio = new Date(hoy.getFullYear(), 0, 0);
  const dia = Math.floor((hoy.getTime() - inicio.getTime()) / 86400000);
  return palabras[dia % palabras.length];
}
